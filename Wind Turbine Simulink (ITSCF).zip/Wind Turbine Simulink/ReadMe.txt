The wind turbine inter-turn short circuit fault (ITSCF) was simulated based on the wind turbine example sourced from https://www.mathworks.com/help/sps/ug/wind-turbine.html

Default ITSCF setting:
faulty phase = "A"
faulty winding ratio = 0.2
short circuit resistance(Ohm) = 0.0001 

To change the setting of faulty winding ratio and short circuit resistance, please change fwr and ShortCircuitResistance parameters in sscv_wind_turbine_input.m, respectively.

Contributor: Soroush Senemmar, Jingyi Yan
Laboratory: Design and Optimization of Energy Systems (DOES) Laboratory
Date: 5/26/2024
